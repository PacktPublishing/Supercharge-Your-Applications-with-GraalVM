package com.abvijay.chapter9.spring.bookinfoservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookInfoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
